"""Documentation generation from code structure, memory and history."""
import llm, memory, scanner
from pathlib import Path


def generate(project):
    root = Path(project["path"])
    files = [f["path"] for f in scanner.scan(root)][:80]
    readme = next((f["text"][:1500] for f in scanner.scan(root) if f["path"].lower() == "readme.md"), "")
    mem = memory.as_text(project["id"])
    prompt = (f"Write concise Markdown project documentation for '{project['name']}'.\n"
              f"Sections: Overview, Structure, Key decisions, Known issues & solutions, Progress, Next steps.\n\n"
              f"FILES:\n" + "\n".join(files) + f"\n\nREADME EXCERPT:\n{readme}\n\nPROJECT MEMORY:\n{mem}")
    out = llm.complete("You write accurate developer documentation from the facts given. Do not invent features.",
                       [{"role": "user", "content": prompt}], max_tokens=2000)
    if out: return out
    s = memory.snapshot(project["id"])
    bl = lambda xs: "\n".join(f"- {x}" for x in xs) or "- none"
    return (f"# {project['name']}\n\n## Structure\n" + bl(files[:40]) +
            f"\n\n## Key decisions\n{bl(s['decisions'])}\n\n## Known issues\n{bl(s['bugs'])}"
            f"\n\n## Solutions\n{bl(s['solutions'])}\n\n## Progress ({s['progress']}%)\n"
            f"Done:\n{bl(s['completed'])}\n\nPending:\n{bl(s['pending'])}\n\n"
            f"_Set ANTHROPIC_API_KEY for a written summary instead of this template._\n")
