"""RAG: question -> semantic search -> project context -> LLM -> grounded answer."""
import json, db, llm, memory, vectorstore as vs

SYSTEM = """You are AI Workspace, a project-aware assistant for a software developer.
Answer using ONLY the project memory and code/document excerpts provided. Mention file paths
when relevant. If the context does not contain the answer, say so plainly instead of guessing."""


def answer(project, question):
    pid = project["id"]
    hits = vs.query(project["path"], question, n=6)
    context = "\n\n".join(f"[{h['path']} line {h['start_line']}]\n{h['text']}" for h in hits) or "(no matching files)"
    history = db.query("SELECT role,text FROM messages WHERE project_id=? ORDER BY id DESC LIMIT 6", (pid,))[::-1]
    msgs = [{"role": "user" if m["role"] == "user" else "assistant", "text": m["text"]} for m in history]
    msgs = [{"role": m["role"], "content": m["text"]} for m in msgs]
    msgs.append({"role": "user", "content":
                 f"PROJECT MEMORY:\n{memory.as_text(pid)}\n\nRETRIEVED CONTEXT:\n{context}\n\nQUESTION: {question}"})

    text = llm.complete(SYSTEM, msgs)
    if text is None:  # no API key: still useful, show what retrieval found
        snippets = "\n\n".join(f"• {h['path']} (line {h['start_line']}):\n{h['text'][:300]}" for h in hits[:3])
        text = ("No ANTHROPIC_API_KEY set, so here is the project context I retrieved:\n\n"
                f"{memory.as_text(pid)}\n\n{snippets}")
    sources = list(dict.fromkeys(h["path"] for h in hits))[:5]

    db.execute("INSERT INTO messages(project_id,role,text,sources,created_at) VALUES(?,?,?,?,?)",
               (pid, "user", question, "[]", db.now()))
    db.execute("INSERT INTO messages(project_id,role,text,sources,created_at) VALUES(?,?,?,?,?)",
               (pid, "ai", text, json.dumps(sources), db.now()))
    memory.log(pid, "activity", f"Asked: {question[:80]}")
    return {"text": text, "sources": sources}
