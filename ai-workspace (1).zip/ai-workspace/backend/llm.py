"""LLM access (Anthropic). Returns None if no key is configured."""
import os


def complete(system, messages, max_tokens=1200):
    key = os.getenv("ANTHROPIC_API_KEY")
    if not key: return None
    try:
        import anthropic
        r = anthropic.Anthropic(api_key=key).messages.create(
            model=os.getenv("LLM_MODEL", "claude-sonnet-5-5"),
            max_tokens=max_tokens, system=system, messages=messages)
        return "".join(b.text for b in r.content if b.type == "text")
    except Exception as e:
        return f"LLM request failed: {e}"
