"""AI Workspace API. Run:  uvicorn main:app --reload --port 8000"""
import json
from pathlib import Path
from dotenv import load_dotenv
load_dotenv()

from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel

import db, scanner, memory, rag, docs
import vectorstore as vs

app = FastAPI(title="AI Workspace API")
app.add_middleware(CORSMiddleware, allow_origins=["http://localhost:5173"],
                   allow_methods=["*"], allow_headers=["*"])
db.init()


class PathBody(BaseModel): path: str
class Question(BaseModel): question: str
class MemoryItem(BaseModel): kind: str; text: str
class TaskBody(BaseModel): title: str
class TaskPatch(BaseModel): done: bool


def project():
    p = db.current_project()
    if not p: raise HTTPException(400, "Open a project first.")
    return p


@app.post("/api/projects/open")
def open_project(body: PathBody):
    root = Path(body.path).expanduser()
    if not root.is_dir(): raise HTTPException(400, f"Not a folder: {body.path}")
    root = root.resolve()
    pid = db.upsert_project(str(root), root.name)
    vs.reset(str(root))
    chunks, files = [], 0
    for f in scanner.scan(root):
        files += 1
        chunks.extend(scanner.chunk_file(f))
    vs.add_chunks(str(root), chunks)
    memory.reindex(pid, str(root))
    memory.log(pid, "activity", f"Opened project and indexed {files} files")
    return {"open": True, "name": root.name, "path": str(root), "files": files,
            "chunks": len(chunks), "tree": scanner.build_tree(root)}


@app.get("/api/projects/current")
def current():
    p = db.current_project()
    if not p or not Path(p["path"]).is_dir(): return {"open": False}
    return {"open": True, "name": p["name"], "path": p["path"], "tree": scanner.build_tree(Path(p["path"]))}


@app.get("/api/file")
def read_file(path: str):
    p = project()
    try:
        f = scanner.safe_path(Path(p["path"]), path)
        text = f.read_text(encoding="utf-8")
    except (ValueError, OSError, UnicodeDecodeError) as e:
        raise HTTPException(400, f"Cannot open file: {e}")
    lines = text.splitlines()
    return {"path": path, "content": "\n".join(lines[:3000]), "truncated": len(lines) > 3000}


@app.get("/api/search")
def search(q: str):
    p = project()
    seen, out = set(), []
    for h in vs.query(p["path"], q, n=12):
        if h["kind"] == "memory" or h["path"] in seen: continue
        seen.add(h["path"])
        out.append({"path": h["path"], "snippet": h["text"].split("\n", 1)[-1][:120]})
    return out[:5]


@app.post("/api/chat")
def chat(body: Question):
    return rag.answer(project(), body.question)


@app.get("/api/chat/history")
def history():
    rows = db.query("SELECT role,text,sources FROM messages WHERE project_id=? ORDER BY id DESC LIMIT 50",
                    (project()["id"],))[::-1]
    return [{"role": r["role"], "text": r["text"], "sources": json.loads(r["sources"] or "[]")} for r in rows]


@app.get("/api/memory")
def get_memory():
    return memory.snapshot(project()["id"])


@app.post("/api/memory/items")
def add_item(body: MemoryItem):
    if body.kind not in memory.KINDS: raise HTTPException(400, "kind must be decision, bug or solution")
    memory.log(project()["id"], body.kind, body.text.strip())
    return memory.snapshot(project()["id"])


@app.post("/api/tasks")
def add_task(body: TaskBody):
    memory.add_task(project()["id"], body.title.strip())
    return memory.snapshot(project()["id"])


@app.patch("/api/tasks/{task_id}")
def patch_task(task_id: int, body: TaskPatch):
    memory.set_task(project()["id"], task_id, body.done)
    return memory.snapshot(project()["id"])


@app.post("/api/docs/generate")
def generate_docs():
    return {"markdown": docs.generate(project())}
