"""Project memory: decisions, bugs, solutions, tasks, activity, progress, next-task suggestion."""
import db, vectorstore as vs

KINDS = {"decision": "decisions", "bug": "bugs", "solution": "solutions"}


def _path(pid):
    return db.query("SELECT path FROM projects WHERE id=?", (pid,))[0]["path"]


def _index_task(pid, t):
    state = "done" if t["done"] else "pending"
    vs.upsert_note(_path(pid), f"task-{t['id']}", f"Task ({state}): {t['title']}", "task")


def log(pid, kind, text):
    mid = db.execute("INSERT INTO memory_items(project_id,kind,text,created_at) VALUES(?,?,?,?)",
                     (pid, kind, text, db.now()))
    if kind != "activity":
        vs.upsert_note(_path(pid), f"mem-{mid}", f"{kind.capitalize()}: {text}", kind)


def add_task(pid, title):
    tid = db.execute("INSERT INTO tasks(project_id,title,done,created_at) VALUES(?,?,0,?)", (pid, title, db.now()))
    _index_task(pid, {"id": tid, "title": title, "done": 0})
    log(pid, "activity", f"Added task: {title}")
    return tid


def set_task(pid, tid, done):
    db.execute("UPDATE tasks SET done=? WHERE id=? AND project_id=?", (int(done), tid, pid))
    t = db.query("SELECT * FROM tasks WHERE id=?", (tid,))[0]
    _index_task(pid, t)
    log(pid, "activity", f"{'Completed' if done else 'Reopened'} task: {t['title']}")


def reindex(pid, project_path):
    for i in db.query("SELECT * FROM memory_items WHERE project_id=? AND kind!='activity'", (pid,)):
        vs.upsert_note(project_path, f"mem-{i['id']}", f"{i['kind'].capitalize()}: {i['text']}", i["kind"])
    for t in db.query("SELECT * FROM tasks WHERE project_id=?", (pid,)):
        _index_task(pid, t)


def snapshot(pid):
    items = db.query("SELECT * FROM memory_items WHERE project_id=? ORDER BY id DESC", (pid,))
    tasks = db.query("SELECT * FROM tasks WHERE project_id=? ORDER BY id", (pid,))
    by = lambda k: [i["text"] for i in items if i["kind"] == k]
    pending = [t["title"] for t in tasks if not t["done"]]
    bugs = by("bug")
    nxt = pending[0] if pending else (f"Resolve bug: {bugs[0]}" if bugs else None)
    return {
        "last_activity": (by("activity") or ["No activity yet"])[0],
        "completed": [t["title"] for t in tasks if t["done"]],
        "pending": pending,
        "decisions": by("decision"), "bugs": bugs, "solutions": by("solution"),
        "progress": round(100 * sum(t["done"] for t in tasks) / len(tasks)) if tasks else 0,
        "next_task": nxt,
        "tasks": [{"id": t["id"], "title": t["title"], "done": bool(t["done"])} for t in tasks],
    }


def as_text(pid):
    s = snapshot(pid)
    f = lambda k: "; ".join(s[k]) or "none"
    return (f"Last activity: {s['last_activity']}\nCompleted tasks: {f('completed')}\n"
            f"Pending tasks: {f('pending')}\nDecisions: {f('decisions')}\nBugs: {f('bugs')}\n"
            f"Solutions: {f('solutions')}\nProgress: {s['progress']}%\nSuggested next: {s['next_task'] or 'none'}")
