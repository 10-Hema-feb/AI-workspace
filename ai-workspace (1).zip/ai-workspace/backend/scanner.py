"""Project files -> file scanning -> text & code chunking."""
import os
from pathlib import Path

SKIP_DIRS = {".git", "node_modules", "venv", ".venv", "__pycache__", "dist", "build",
             ".idea", ".vscode", "data", ".next", "target", ".chroma"}
CODE_EXT = {".py", ".js", ".jsx", ".ts", ".tsx", ".java", ".c", ".cpp", ".h", ".cs", ".go",
            ".rs", ".php", ".rb", ".html", ".css", ".sql", ".sh", ".kt", ".swift"}
PROSE_EXT = {".md", ".txt", ".rst"}
CONFIG_EXT = {".json", ".yml", ".yaml", ".toml", ".ini", ".cfg", ".xml", ".env"}
MAX_BYTES = 300_000


def classify(p: Path):
    ext = p.suffix.lower()
    if ext in CODE_EXT: return "code"
    if ext in PROSE_EXT: return "prose"
    if ext in CONFIG_EXT or p.name in {"Dockerfile", "Makefile", "requirements.txt"}: return "config"
    return None


def build_tree(root: Path, base: Path = None):
    base = base or root
    nodes = []
    try:
        entries = sorted(root.iterdir(), key=lambda e: (e.is_file(), e.name.lower()))
    except OSError:
        return nodes
    for e in entries:
        if e.name.startswith(".") and e.name not in {".env.example"}: continue
        rel = e.relative_to(base).as_posix()
        if e.is_dir():
            if e.name in SKIP_DIRS: continue
            nodes.append({"name": e.name, "path": rel, "type": "dir", "children": build_tree(e, base)})
        elif classify(e):
            nodes.append({"name": e.name, "path": rel, "type": "file"})
    return nodes


def scan(root: Path):
    """Yield {path, kind, text} for every readable project file."""
    for dirpath, dirs, names in os.walk(root):
        dirs[:] = [d for d in dirs if d not in SKIP_DIRS and not d.startswith(".")]
        for n in names:
            p = Path(dirpath) / n
            kind = classify(p)
            if not kind: continue
            try:
                if p.stat().st_size > MAX_BYTES: continue
                text = p.read_text(encoding="utf-8")
            except (OSError, UnicodeDecodeError):
                continue
            if text.strip():
                yield {"path": p.relative_to(root).as_posix(), "kind": kind, "text": text}


def chunk_code(text, size=40, overlap=8):
    lines = text.splitlines()
    step = size - overlap
    for i in range(0, len(lines), step):
        block = "\n".join(lines[i:i + size])
        if block.strip():
            yield i + 1, block
        if i + size >= len(lines): break


def chunk_prose(text, max_chars=1200):
    buf, start = "", 1
    for para in [p for p in text.split("\n\n") if p.strip()]:
        if buf and len(buf) + len(para) > max_chars:
            yield start, buf
            start, buf = start + buf.count("\n") + 2, ""
        buf += para + "\n\n"
    if buf.strip(): yield start, buf


def chunk_file(f):
    fn = chunk_code if f["kind"] == "code" else chunk_prose
    for start, block in fn(f["text"]):
        yield {"id": f"{f['path']}:{start}", "text": f"# {f['path']}\n{block}",
               "path": f["path"], "kind": f["kind"], "start_line": start}


def safe_path(root: Path, rel: str) -> Path:
    p = (root / rel).resolve()
    if root.resolve() not in p.parents and p != root.resolve():
        raise ValueError("Path is outside the project")
    return p
