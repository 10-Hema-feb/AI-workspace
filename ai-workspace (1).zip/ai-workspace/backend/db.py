"""SQLite storage: projects, memory items, tasks, chat messages."""
import os, sqlite3
from datetime import datetime

DB_PATH = os.getenv("DATABASE_PATH", "data/workspace.db")


def _conn():
    os.makedirs(os.path.dirname(DB_PATH) or ".", exist_ok=True)
    c = sqlite3.connect(DB_PATH)
    c.row_factory = sqlite3.Row
    return c


def init():
    c = _conn()
    c.executescript("""
    CREATE TABLE IF NOT EXISTS projects(
        id INTEGER PRIMARY KEY AUTOINCREMENT, path TEXT UNIQUE, name TEXT, opened_at TEXT);
    CREATE TABLE IF NOT EXISTS memory_items(
        id INTEGER PRIMARY KEY AUTOINCREMENT, project_id INTEGER, kind TEXT, text TEXT, created_at TEXT);
    CREATE TABLE IF NOT EXISTS tasks(
        id INTEGER PRIMARY KEY AUTOINCREMENT, project_id INTEGER, title TEXT, done INTEGER DEFAULT 0, created_at TEXT);
    CREATE TABLE IF NOT EXISTS messages(
        id INTEGER PRIMARY KEY AUTOINCREMENT, project_id INTEGER, role TEXT, text TEXT, sources TEXT, created_at TEXT);
    """)
    c.commit(); c.close()


def now():
    return datetime.now().isoformat(timespec="seconds")


def query(sql, args=()):
    c = _conn()
    try:
        return [dict(r) for r in c.execute(sql, args).fetchall()]
    finally:
        c.close()


def execute(sql, args=()):
    c = _conn()
    try:
        cur = c.execute(sql, args)
        c.commit()
        return cur.lastrowid
    finally:
        c.close()


def upsert_project(path, name):
    execute("""INSERT INTO projects(path,name,opened_at) VALUES(?,?,?)
               ON CONFLICT(path) DO UPDATE SET opened_at=excluded.opened_at""", (path, name, now()))
    return query("SELECT id FROM projects WHERE path=?", (path,))[0]["id"]


def current_project():
    rows = query("SELECT * FROM projects ORDER BY opened_at DESC, id DESC LIMIT 1")
    return rows[0] if rows else None
