"""Embeddings + vector database (ChromaDB). Uses Chroma's built-in local embedding model."""
import hashlib, os
import chromadb

_client = chromadb.PersistentClient(path=os.getenv("CHROMA_PATH", "data/chroma"))


def _name(project_path):
    return "proj_" + hashlib.md5(project_path.encode()).hexdigest()[:16]


def _col(project_path):
    return _client.get_or_create_collection(_name(project_path), metadata={"hnsw:space": "cosine"})


def reset(project_path):
    try: _client.delete_collection(_name(project_path))
    except Exception: pass
    return _col(project_path)


def add_chunks(project_path, chunks, batch=100):
    col = _col(project_path)
    for i in range(0, len(chunks), batch):
        b = chunks[i:i + batch]
        col.upsert(ids=[c["id"] for c in b], documents=[c["text"] for c in b],
                   metadatas=[{"path": c["path"], "kind": c["kind"], "start_line": c["start_line"]} for c in b])


def upsert_note(project_path, note_id, text, kind):
    """Decisions, bugs, tasks... are searchable alongside files."""
    _col(project_path).upsert(ids=[note_id], documents=[text],
                              metadatas=[{"path": f"memory:{kind}", "kind": "memory", "start_line": 0}])


def query(project_path, q, n=6):
    col = _col(project_path)
    total = col.count()
    if total == 0: return []
    r = col.query(query_texts=[q], n_results=min(n, total))
    return [{"text": d, **m, "distance": dist}
            for d, m, dist in zip(r["documents"][0], r["metadatas"][0], r["distances"][0])]
