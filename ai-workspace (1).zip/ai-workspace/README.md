# AI Workspace

React frontend + FastAPI backend + ChromaDB (vector search) + SQLite (project memory) + LLM (RAG).

## 1. Backend
```bash
cd backend
python -m venv venv
venv\Scripts\activate          # Windows   (Mac/Linux: source venv/bin/activate)
pip install -r requirements.txt
copy .env.example .env         # Mac/Linux: cp .env.example .env  -> add your ANTHROPIC_API_KEY
uvicorn main:app --reload --port 8000
```
First run downloads Chroma's small local embedding model (internet needed once).

## 2. Frontend (new terminal)
```bash
cd frontend
npm install
npm run dev
```
Open http://localhost:5173, paste a project folder path, press **Open project**.

## Flow
Open project -> scan files -> chunk -> embed -> ChromaDB. Ask a question -> semantic search ->
project memory + chunks sent to the LLM -> grounded answer. Tasks, decisions, bugs and solutions
live in SQLite and are also embedded, so chat can retrieve them across sessions.

## API
POST /api/projects/open | GET /api/projects/current | GET /api/file | GET /api/search
POST /api/chat | GET /api/chat/history | GET /api/memory | POST /api/memory/items
POST /api/tasks | PATCH /api/tasks/{id} | POST /api/docs/generate
