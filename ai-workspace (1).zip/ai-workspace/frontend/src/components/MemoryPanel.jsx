import { useState } from "react";
import { addMemoryItem, addTask, toggleTask } from "../api.js";

const sections = [
  ["completed", "Completed", "var(--green)"],
  ["pending", "Pending", "var(--amber)"],
  ["decisions", "Decisions", "var(--indigo)"],
  ["bugs", "Bugs", "var(--red)"],
  ["solutions", "Solutions", "var(--green)"],
];

export default function MemoryPanel({ data, ready, onChange, onError }) {
  const [kind, setKind] = useState("decision");
  const [text, setText] = useState("");
  const [task, setTask] = useState("");

  const run = async (fn) => { try { onChange(await fn()); } catch (e) { onError(e.message); } };

  if (!ready) return (<><h2 className="panel-title">Project memory</h2><p className="empty">Open a project to build its memory.</p></>);
  if (!data) return (<><h2 className="panel-title">Project memory</h2><p className="empty">Loading…</p></>);

  return (
    <>
      <h2 className="panel-title">Project memory</h2>
      {data.next_task && (
        <div className="next-card">
          <div className="small muted">Suggested next task</div>
          <div className="next-title">{data.next_task}</div>
        </div>
      )}
      <div className="progress"><div className="progress-bar" style={{ width: `${data.progress}%` }} /></div>
      <div className="small muted">{data.progress}% complete · {data.last_activity}</div>

      {sections.map(([key, label, color]) => data[key].length > 0 && (
        <div key={key} className="mem-section" style={{ borderLeftColor: color }}>
          <div className="mem-label">{label}</div>
          {data[key].map((item, i) => <div key={i} className="mem-item">{item}</div>)}
        </div>
      ))}

      <h3 className="sub-title">Tasks</h3>
      {data.tasks.map((t) => (
        <label key={t.id} className={`task ${t.done ? "done" : ""}`}>
          <input type="checkbox" checked={t.done} onChange={() => run(() => toggleTask(t.id, !t.done))} /> {t.title}
        </label>
      ))}
      <form className="row" onSubmit={(e) => { e.preventDefault(); if (task.trim()) { run(() => addTask(task)); setTask(""); } }}>
        <input className="input" placeholder="New task" value={task} onChange={(e) => setTask(e.target.value)} />
        <button className="btn">Add</button>
      </form>

      <h3 className="sub-title">Record to memory</h3>
      <form className="row" onSubmit={(e) => { e.preventDefault(); if (text.trim()) { run(() => addMemoryItem(kind, text)); setText(""); } }}>
        <select className="input select" value={kind} onChange={(e) => setKind(e.target.value)}>
          <option value="decision">Decision</option><option value="bug">Bug</option><option value="solution">Solution</option>
        </select>
        <input className="input" placeholder="What happened?" value={text} onChange={(e) => setText(e.target.value)} />
        <button className="btn">Save</button>
      </form>
    </>
  );
}
