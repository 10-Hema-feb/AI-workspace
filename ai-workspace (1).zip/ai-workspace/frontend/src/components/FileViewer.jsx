export default function FileViewer({ file }) {
  if (!file) return <p className="empty">Select a file in the tree to view it.</p>;
  return (
    <div className="viewer">
      <div className="viewer-path">{file.path}</div>
      <pre className="code">
        {file.content.split("\n").map((line, i) => (
          <div key={i}><span className="ln">{i + 1}</span>{line}</div>
        ))}
        {file.truncated && <div className="muted">… file truncated at 3000 lines</div>}
      </pre>
    </div>
  );
}
