import { useState } from "react";
import { generateDocs } from "../api.js";

export default function DocsPanel({ ready, projectName }) {
  const [md, setMd] = useState("");
  const [busy, setBusy] = useState(false);
  const [err, setErr] = useState("");

  async function run() {
    setBusy(true); setErr("");
    try { setMd((await generateDocs()).markdown); } catch (e) { setErr(e.message); }
    setBusy(false);
  }
  function download() {
    const a = document.createElement("a");
    a.href = URL.createObjectURL(new Blob([md], { type: "text/markdown" }));
    a.download = `${projectName || "project"}-docs.md`;
    a.click();
  }

  return (
    <div className="docs">
      <div className="docs-bar">
        <button className="btn" onClick={run} disabled={!ready || busy}>
          {busy ? "Writing documentation…" : "Generate documentation"}
        </button>
        {md && <button className="btn ghost" onClick={download}>Download .md</button>}
      </div>
      {err && <p className="empty">{err}</p>}
      {md ? <pre className="doc-text">{md}</pre>
          : <p className="empty">Turns your code, decisions and history into a readable summary.</p>}
    </div>
  );
}
