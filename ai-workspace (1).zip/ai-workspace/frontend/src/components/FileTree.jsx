import { useState } from "react";
import { searchFiles } from "../api.js";

function Node({ node, depth, onOpen }) {
  const [open, setOpen] = useState(depth < 1);
  const isDir = node.type === "dir";
  return (
    <div>
      <div className="node" style={{ paddingLeft: 8 + depth * 14 }}
           onClick={() => (isDir ? setOpen(!open) : onOpen(node.path))}>
        <span className="node-icon">{isDir ? (open ? "▾" : "▸") : "·"}</span>{node.name}
      </div>
      {isDir && open && node.children.map((c) => <Node key={c.path} node={c} depth={depth + 1} onOpen={onOpen} />)}
    </div>
  );
}

export default function FileTree({ tree, onOpen, ready }) {
  const [q, setQ] = useState("");
  const [hits, setHits] = useState([]);

  async function onSearch(e) {
    const v = e.target.value;
    setQ(v);
    if (v.trim().length < 3 || !ready) return setHits([]);
    try { setHits(await searchFiles(v)); } catch { setHits([]); }
  }

  return (
    <>
      <h2 className="panel-title">Files</h2>
      <input className="input" placeholder="Search by meaning, e.g. “token expiry”"
             value={q} onChange={onSearch} disabled={!ready} />
      {hits.length > 0 && (
        <div className="hits">
          <div className="muted small">Closest matches</div>
          {hits.map((h) => (
            <div key={h.path} className="hit" onClick={() => onOpen(h.path)}>
              <div>{h.path}</div><div className="muted small snippet">{h.snippet}</div>
            </div>
          ))}
        </div>
      )}
      <div className="tree">
        {tree ? tree.map((n) => <Node key={n.path} node={n} depth={0} onOpen={onOpen} />)
              : <p className="empty">Enter a project folder above and press Open project.</p>}
      </div>
    </>
  );
}
