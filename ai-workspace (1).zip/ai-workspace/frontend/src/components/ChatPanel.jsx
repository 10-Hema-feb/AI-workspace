import { useEffect, useRef, useState } from "react";
import { askQuestion } from "../api.js";

export default function ChatPanel({ messages, setMessages, ready, onAnswered }) {
  const [input, setInput] = useState("");
  const [busy, setBusy] = useState(false);
  const endRef = useRef(null);

  useEffect(() => { endRef.current?.scrollIntoView({ behavior: "smooth" }); }, [messages, busy]);

  async function send() {
    const q = input.trim();
    if (!q || busy || !ready) return;
    setInput("");
    setMessages((m) => [...m, { role: "user", text: q }]);
    setBusy(true);
    try {
      const res = await askQuestion(q);
      setMessages((m) => [...m, { role: "ai", ...res }]);
      onAnswered();
    } catch (e) {
      setMessages((m) => [...m, { role: "ai", text: `Something went wrong: ${e.message}` }]);
    }
    setBusy(false);
  }

  return (
    <>
      <div className="messages">
        {messages.length === 0 && (
          <p className="empty">{ready ? "Ask about your project, e.g. “Where did I stop?” or “What does auth.py do?”"
                                      : "Open a project to start chatting."}</p>
        )}
        {messages.map((m, i) => (
          <div key={i} className={`msg ${m.role}`}>
            <div className="bubble">{m.text}</div>
            {m.sources?.length > 0 && <div className="sources">Based on: {m.sources.join(", ")}</div>}
          </div>
        ))}
        {busy && <div className="msg ai"><div className="bubble muted">Searching project memory…</div></div>}
        <div ref={endRef} />
      </div>
      <div className="composer">
        <textarea className="input" rows={2} value={input} disabled={!ready}
          placeholder="Ask anything about your project"
          onChange={(e) => setInput(e.target.value)}
          onKeyDown={(e) => { if (e.key === "Enter" && !e.shiftKey) { e.preventDefault(); send(); } }} />
        <button className="btn" onClick={send} disabled={busy || !ready}>Send</button>
      </div>
    </>
  );
}
