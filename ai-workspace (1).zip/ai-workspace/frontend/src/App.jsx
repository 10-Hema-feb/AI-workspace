import { useCallback, useEffect, useState } from "react";
import FileTree from "./components/FileTree.jsx";
import ChatPanel from "./components/ChatPanel.jsx";
import MemoryPanel from "./components/MemoryPanel.jsx";
import FileViewer from "./components/FileViewer.jsx";
import DocsPanel from "./components/DocsPanel.jsx";
import { openProject, currentProject, getMemory, getHistory, readFile } from "./api.js";

export default function App() {
  const [project, setProject] = useState(null);
  const [mem, setMem] = useState(null);
  const [messages, setMessages] = useState([]);
  const [pathInput, setPathInput] = useState("");
  const [indexing, setIndexing] = useState(false);
  const [error, setError] = useState("");
  const [tab, setTab] = useState("chat");
  const [file, setFile] = useState(null);

  const refreshMemory = useCallback(async () => {
    try { setMem(await getMemory()); } catch (e) { setError(e.message); }
  }, []);

  useEffect(() => {
    (async () => {
      try {
        const p = await currentProject();
        if (p.open) {
          setProject(p); setPathInput(p.path);
          setMessages(await getHistory());
          await refreshMemory();
        }
      } catch {
        setError("Cannot reach the backend on port 8000. Start it with: uvicorn main:app --reload");
      }
    })();
  }, [refreshMemory]);

  async function handleOpen() {
    if (!pathInput.trim() || indexing) return;
    setIndexing(true); setError("");
    try {
      setProject(await openProject(pathInput.trim()));
      setMessages(await getHistory());
      await refreshMemory();
      setTab("chat"); setFile(null);
    } catch (e) { setError(e.message); }
    setIndexing(false);
  }

  async function handleOpenFile(path) {
    try { setFile(await readFile(path)); setTab("file"); } catch (e) { setError(e.message); }
  }

  const ready = !!project;
  return (
    <div className="app">
      <header className="topbar">
        <strong className="brand">AI Workspace</strong>
        <input className="path-input" placeholder="Project folder, e.g. C:/projects/shop-api"
               value={pathInput} onChange={(e) => setPathInput(e.target.value)}
               onKeyDown={(e) => e.key === "Enter" && handleOpen()} />
        <button className="btn" onClick={handleOpen} disabled={indexing}>
          {indexing ? "Building memory…" : "Open project"}
        </button>
      </header>
      {error && <div className="error" onClick={() => setError("")}>{error}</div>}

      <main className="layout">
        <aside className="panel"><FileTree tree={project?.tree} onOpen={handleOpenFile} ready={ready} /></aside>

        <section className="panel center">
          <div className="tabs">
            {[["chat", "Chat"], ["file", "File"], ["docs", "Docs"]].map(([id, label]) => (
              <button key={id} className={`tab ${tab === id ? "active" : ""}`} onClick={() => setTab(id)}>{label}</button>
            ))}
            {ready && <span className="muted small tab-note">{project.name}</span>}
          </div>
          {tab === "chat" && <ChatPanel messages={messages} setMessages={setMessages} ready={ready}
                                        onAnswered={refreshMemory} />}
          {tab === "file" && <FileViewer file={file} />}
          {tab === "docs" && <DocsPanel ready={ready} projectName={project?.name} />}
        </section>

        <aside className="panel"><MemoryPanel data={mem} ready={ready} onChange={setMem} onError={setError} /></aside>
      </main>
    </div>
  );
}
