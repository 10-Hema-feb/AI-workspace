// All backend calls live here.
async function req(url, opts) {
  const r = await fetch(url, opts);
  if (!r.ok) {
    let msg = r.statusText;
    try { msg = (await r.json()).detail || msg; } catch {}
    throw new Error(msg);
  }
  return r.json();
}
const send = (method, body) => ({ method, headers: { "Content-Type": "application/json" }, body: JSON.stringify(body) });

export const openProject = (path) => req("/api/projects/open", send("POST", { path }));
export const currentProject = () => req("/api/projects/current");
export const getMemory = () => req("/api/memory");
export const addMemoryItem = (kind, text) => req("/api/memory/items", send("POST", { kind, text }));
export const addTask = (title) => req("/api/tasks", send("POST", { title }));
export const toggleTask = (id, done) => req(`/api/tasks/${id}`, send("PATCH", { done }));
export const searchFiles = (q) => req(`/api/search?q=${encodeURIComponent(q)}`);
export const readFile = (path) => req(`/api/file?path=${encodeURIComponent(path)}`);
export const askQuestion = (question) => req("/api/chat", send("POST", { question }));
export const getHistory = () => req("/api/chat/history");
export const generateDocs = () => req("/api/docs/generate", send("POST", {}));
